package wolvsdead;

import java.util.Random;

public class Personaje {

    private String nombre;
    private double vida;
    private double danioMax;
    private boolean probRegeneracion = false;
    private double probEvacion;

    private Random random = new Random();

    public Personaje(String nombre, double vida, double danioMax, double probEvacion) {
        this.nombre = nombre;
        this.vida = vida;
        this.danioMax = danioMax;
        this.probEvacion = probEvacion;
    }

    public boolean estarVivo() {
        return vida > 0;
    }

    public boolean intentoEvadir() {
        return random.nextDouble() < probEvacion;
    }

    public double atacar() {
        return random.nextDouble() * (danioMax - 10) + 10;
    }


    public String getNombre() {
        return nombre;
    }

    public double getVida() {
        return vida;
    }

    public double getDanioMax() {
        return danioMax;
    }

    public boolean isProbRegeneracion() {
        return probRegeneracion;
    }

    public double getProbEvacion() {
        return probEvacion;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setVida(double vida) {
        this.vida = vida;
    }

    public void setDanioMax(double danioMax) {
        this.danioMax = danioMax;
    }

    public void setProbRegeneracion(boolean probRegeneracion) {
        this.probRegeneracion = probRegeneracion;
    }

    public void setProbEvacion(double probEvacion) {
        this.probEvacion = probEvacion;
    }
}
