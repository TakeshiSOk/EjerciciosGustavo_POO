package wolvsdead;

import java.util.Scanner;

public class WolVsDead {

    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);

        System.out.print("Vida  de Deadpool: ");
        double vidaD = sc.nextDouble();
        System.out.print("Vida  de Wolverine: ");
        double vidaW = sc.nextDouble();

        Personaje deadpool = new Personaje("Deadpool", vidaD, 100, 0.25);
        Personaje wolverine = new Personaje("Wolverine", vidaW, 120, 0.20);

        int turno = 1;

        while (deadpool.estarVivo() && wolverine.estarVivo()) {
            System.out.println("=== Turno " + turno + " ===");

            // Ataque de Deadpool
            if (!deadpool.isProbRegeneracion()) {
                if (!wolverine.intentoEvadir()) {
                    double danio = deadpool.atacar();
                    System.out.println("Deadpool se tira con sus katanas " + danio);
                    wolverine.setVida(wolverine.getVida() - danio);

                    if (danio == deadpool.getDanioMax()) {
                        wolverine.setProbRegeneracion(true);
                        System.out.println("un golpe muy fuerte Wolverine no puede atacar");
                    }
                } else {
                    System.out.println("Wolverine dodgeo el golpe ");
                }
            } else {
                System.out.println("Deadpool está recuperandose del golpe");
                deadpool.setProbRegeneracion(false);
            }

            if (!wolverine.estarVivo()) break;

            // Ataque de Wolverine
            if (!wolverine.isProbRegeneracion()) {
                if (!deadpool.intentoEvadir()) {
                    double danio = wolverine.atacar();
                    System.out.println("Wolverine arremete con sus garras " + danio);
                    deadpool.setVida(deadpool.getVida() - danio);

                    if (danio == wolverine.getDanioMax()) {
                        deadpool.setProbRegeneracion(true);
                        System.out.println("un golpe muy fuerte Deadpool no aguanta este turno");
                    }
                } else {
                    System.out.println("Deadpool dodgea el ataque");
                }
            } else {
                System.out.println("Wolverine está recuperandose del golpe ");
                wolverine.setProbRegeneracion(false);
            }

            // Mostrar vida actual
            System.out.println("Vida de Deadpool: " + Math.max(deadpool.getVida(), 0));
            System.out.println("Vida de Wolverine: " + Math.max(wolverine.getVida(), 0));
            System.out.println();

            Thread.sleep(1000);
            turno++;
        }

        // Resultado final
        System.out.println("=== Combate finalizado ===");
        if (deadpool.estarVivo()) {
            System.out.println(" Deadpool gana la batalla");
        } else {
            System.out.println(" Wolverine gana la batalla");
        }

        sc.close();
    }
}
