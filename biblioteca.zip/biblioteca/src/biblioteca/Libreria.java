package biblioteca;

import java.util.ArrayList;

public class Libreria {

    String nombre;
    ArrayList<Libro> coleccionLibros;
    ArrayList<Revista> coleccionRevistas;

    public Libreria(String nombre) {
        this.nombre = nombre;
        coleccionLibros = new ArrayList<Libro>();
        coleccionRevistas = new ArrayList<Revista>();
    }

    public void agregarLibro(Libro libro) {
        coleccionLibros.add(libro);
    }

    public void agregarRevista(Revista revista) {
        coleccionRevistas.add(revista);
    }

    public void mostrarLibros() {
        for (int i = 0; i < coleccionLibros.size(); i++) {
            Libro libro = (Libro) coleccionLibros.get(i);
            libro.imprimir();

        }
    }
    
     public void mostrarRevistas() {
        for (int i = 0; i < coleccionRevistas.size(); i++) {
            Revista revista = (Revista) coleccionRevistas.get(i);
            revista.imprimir();

        }
    }
}        
    
