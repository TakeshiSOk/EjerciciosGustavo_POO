package biblioteca;

import java.util.ArrayList;

public class Biblioteca {
    public static void main(String[] args) {
        ArrayList<Libro> listaLibros = new ArrayList<>();
        ArrayList<Revista> listaRevistas = new ArrayList<>();
        // Agregar libros a la lista
        listaLibros.add(new Libro("La casa de los espíritus", 1982, "Isabel Allende", "Sudamericana", "Allende, I. (1982)"));
        listaLibros.add(new Libro("Los juegos del hambre", 2008, "Suzanne Collins", "Scholastic Press", "Collins, S. (2008)"));
        listaLibros.add(new Libro("Tokio Blues (Norwegian Wood)", 1987, "Haruki Murakami", "Kodansha", "Murakami, H. (1987)"));

        // public Revista(String Titulo, int AnioPublicacion, String Editorial, String periodicidad, String pais)
        // Agregar revista a la lista
        listaRevistas.add(new Revista("Scientific American", 2023, "Springer Nature", "Mensual", "Estados Unidos"));
        listaRevistas.add(new Revista("Nature", 2024, "Springer Nature", "Semanal", "Reino Unido"));
        listaRevistas.add(new Revista("Quo", 2021, "Hearst España", "Mensual", "España"));

        
        // Recorrer e imprimir los libros
        System.out.println("Registro de libros:");
        for (Libro libro : listaLibros) {
            libro.imprimir();
            System.out.println("=================================================================");
        }
        
        System.out.println("");
        
        System.out.println("Registro de revistas:");
        // Recorrer e imprimir revistas
        for (Revista revista : listaRevistas){
            revista.imprimir();
            System.out.println("==================================================================");
        }
    }
}